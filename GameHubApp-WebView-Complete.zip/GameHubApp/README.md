# GameHub — Android WebView Wrapper

این پروژه یک اپ اندروید سبک است که فایل HTML بازی GameHub را داخل WebView اجرا می‌کند.

## محتویات
- اپ کامل HTML/CSS/JS گیم‌هاب (آفلاین)
- پشتیبانی از localStorage
- رابط فارسی و RTL
- آماده برای ساخت APK

## نحوه ساخت APK روی سیستم خودت

### پیش‌نیاز
- Android Studio (پیشنهادی) یا فقط Android SDK + JDK 17
- حداقل ۴ گیگ رم آزاد

### با Android Studio
1. پروژه را باز کن (Open → پوشه GameHubApp)
2. صبر کن تا Gradle sync تمام شود
3. از منوی Build → Build Bundle(s) / APK(s) → Build APK(s)

### با خط فرمان
```bash
# اگر wrapper نداری:
gradle wrapper --gradle-version 8.7

# ساخت نسخه Debug
./gradlew assembleDebug

# فایل خروجی:
# app/build/outputs/apk/debug/app-debug.apk
```

### ساخت نسخه Release (برای گوگل‌پلی)
```bash
# اول یک keystore بساز
keytool -genkey -v -keystore gamehub.keystore -alias gamehub -keyalg RSA -keysize 2048 -validity 10000

# بعد در app/build.gradle بخش signingConfigs را اضافه کن و assembleRelease بزن
./gradlew assembleRelease
```

## نکات مهم
- این نسخه فقط کلاینت وب است (آفلاین/محلی).
- برای نسخه واقعی چندنفره + سرور + تبلیغات + انتشار حرفه‌ای، باید به سمت Flutter یا Capacitor + بک‌اند بروید.
- آیکون فعلی سیستمی است. برای انتشار باید آیکون اختصاصی بگذاری.

## ساختار
```
GameHubApp/
├── app/
│   ├── src/main/
│   │   ├── assets/index.html      ← فایل اصلی گیم‌هاب
│   │   ├── java/.../MainActivity.java
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
├── gradle.properties
└── README.md
```
